import type { Language } from "../i18n";

type MotivationContent = { goldenRulesTitle: string; goldenRules: [string, string][]; quotes: string[] };

const de: MotivationContent = {
  goldenRulesTitle: "Die zehn goldenen Regeln",
  goldenRules: [
    ["Beginne jeden Tag mit einem Erfolg.", "Erledige zuerst eine Aufgabe – und starte mit einem guten Gefühl."], ["Gehe deinen Weg nicht allein.", "Suche Menschen, die dich unterstützen, und sei auch für sie da."], ["Behandle jeden Menschen mit Respekt.", "Charakter zeigt sich darin, wie du mit anderen umgehst."], ["Das Leben ist nicht immer fair – gehe trotzdem weiter.", "Akzeptiere Rückschläge, ohne dein Ziel aus den Augen zu verlieren."], ["Hab keine Angst vor dem Scheitern.", "Jeder Fehler kann dich stärker und besser machen."], ["Trau dich, Risiken einzugehen.", "Wachstum beginnt außerhalb deiner Komfortzone."], ["Stehe mutig für dich und andere ein.", "Lass dich nicht einschüchtern und unterstütze Menschen, die Hilfe brauchen."], ["Zeige Stärke, wenn es am schwierigsten wird.", "Gerade in schweren Zeiten zählt dein Mut am meisten."], ["Richte Menschen auf, die am Boden liegen.", "Wahre Stärke zeigt sich darin, anderen Hoffnung zu geben."], ["Gib niemals auf.", "Bleib dran – auch wenn der Weg länger und härter wird als erwartet."]
  ],
  quotes: [
    "Jede Wiederholung ist eine Entscheidung für dich.", "Disziplin beginnt dort, wo die Ausrede endet.", "Heute stärker als gestern.", "Kleine Sätze ergeben große Ziele.", "Du brauchst keinen perfekten Tag – nur den nächsten Push-up.",
    "Konstanz schlägt Motivation.", "Dein Körper folgt deiner Entscheidung.", "Ein Push-up ist wenig. Tausend Entscheidungen sind Stärke.", "Fang an, bevor du dich bereit fühlst.", "Stärke wächst durch Wiederholung.",
    "Dein Tempo ist richtig, solange du weitermachst.", "Achte auf deine Gedanken. Sie schaffen Taten.", "Nicht aufgeben – anpassen und fortsetzen.", "Du trainierst heute für dein zukünftiges Ich.", "Fortschritt braucht Geduld und Ehrlichkeit.",
    "Jeder saubere Push-up macht dich besser.", "Willenskraft wird durch Handeln stärker.", "Mach es einfach. Mach es sauber. Mach es wieder.", "Deine einzige Konkurrenz bist du von gestern.", "Ein starker Tag beginnt mit einer starken Entscheidung.",
    "Du musst nicht schnell sein, nur konsequent.", "Erfolg entsteht Wiederholung für Wiederholung.", "Bleib ruhig, bleib sauber, bleib dran.", "Auch zehn Wiederholungen bringen dich voran.", "Dein Ziel wartet nicht – geh ihm entgegen.",
    "Disziplin ist Motivation, die geblieben ist.", "Heute zählen nicht die Ausreden, sondern die Wiederholungen.", "Schreibe deinen Fortschritt selbst.", "Stärke zeigt sich im Dranbleiben.", "Du kannst mehr, als der erste Gedanke dir sagt.",
    "Trainiere klug und respektiere deinen Körper.", "Pausen sind erlaubt. Aufgeben ist eine Entscheidung.", "Saubere Technik ist echte Stärke.", "Jeder Anfang darf klein sein.", "Was heute schwer ist, wird morgen Routine.",
    "Deine Gewohnheiten bauen deine Zukunft.", "Ein Ziel wird real, wenn du täglich handelst.", "Bleib ehrlich zu dir und deinen Wiederholungen.", "Du brauchst keinen Applaus, nur deinen Entschluss.", "Der Weg zu hundert beginnt mit einer Wiederholung.",
    "Müdigkeit ist ein Gefühl, Disziplin eine Entscheidung.", "Stärke ist, wieder aufzustehen und weiterzumachen.", "Dein Fortschritt muss niemandem gefallen – nur dir gehören.", "Ein schlechter Tag ist kein schlechtes Ziel.", "Heute ist eine neue Chance zu zählen.",
    "Du baust nicht nur Muskeln, sondern Charakter.", "Wiederholung schafft Vertrauen in dich selbst.", "Das Ziel ist groß, der nächste Schritt ist klein.", "Mach deinen Einsatz sichtbar.", "Jeder ehrliche Satz verdient Respekt.",
    "Du bestimmst, wie deine Geschichte weitergeht.", "Beginne mit dem, was heute möglich ist.", "Kraft wächst, wenn du sie benutzt.", "Bleib geduldig – Fortschritt arbeitet leise.", "Der Wille führt, der Körper lernt.",
    "Heute trainieren. Morgen stolz sein.", "Gehe nicht dorthin, wohin der Weg führt. Gehe dorthin, wo keine Wege sind, und hinterlasse deine Spur.", "Nicht perfekt – aber konsequent.", "Grenzen verschieben sich durch tägliche Arbeit.", "THE.HUMAN.CHOICE: Deine Entscheidung. Dein Fortschritt."
  ]
};

const en: MotivationContent = {
  goldenRulesTitle: "The ten golden rules",
  goldenRules: [
    ["Start each day with a win.", "Complete one task first and begin with a good feeling."], ["Do not walk your path alone.", "Find people who support you, and be there for them too."], ["Treat everyone with respect.", "Character shows in how you treat others."], ["Life is not always fair – keep moving forward anyway.", "Accept setbacks without losing sight of your goal."], ["Do not be afraid to fail.", "Every mistake can make you stronger and better."], ["Dare to take risks.", "Growth begins outside your comfort zone."], ["Stand up bravely for yourself and others.", "Do not be intimidated, and support people who need help."], ["Show strength when things are hardest.", "Your courage matters most in difficult times."], ["Lift up those who are down.", "True strength means giving others hope."], ["Never give up.", "Keep going, even when the road is longer and harder than expected."]
  ],
  quotes: [
    "Every repetition is a choice for yourself.", "Discipline begins where excuses end.", "Stronger today than yesterday.", "Small sets build big goals.", "You do not need a perfect day – just the next push-up.",
    "Consistency beats motivation.", "Your body follows your decision.", "One push-up is small. A thousand decisions are strength.", "Start before you feel ready.", "Strength grows through repetition.",
    "Your pace is right as long as you keep going.", "Watch your thoughts. They create actions.", "Do not give up – adapt and continue.", "You are training today for your future self.", "Progress requires patience and honesty.",
    "Every clean push-up makes you better.", "Willpower grows stronger through action.", "Keep it simple. Keep it clean. Do it again.", "Your only competition is who you were yesterday.", "A strong day begins with a strong decision.",
    "You do not have to be fast, only consistent.", "Success is built one repetition at a time.", "Stay calm, stay clean, keep going.", "Even ten repetitions move you forward.", "Your goal will not wait – move toward it.",
    "Discipline is motivation that stayed.", "Today, repetitions count – not excuses.", "Write your own progress.", "Strength shows in staying with it.", "You can do more than your first thought tells you.",
    "Train smart and respect your body.", "Breaks are allowed. Giving up is a choice.", "Clean technique is real strength.", "Every beginning is allowed to be small.", "What is hard today will be routine tomorrow.",
    "Your habits build your future.", "A goal becomes real when you act every day.", "Stay honest with yourself and your repetitions.", "You do not need applause, only your commitment.", "The road to one hundred begins with one repetition.",
    "Tiredness is a feeling; discipline is a decision.", "Strength is getting back up and carrying on.", "Your progress does not have to please anyone – it only has to be yours.", "A bad day is not a bad goal.", "Today is a new chance to count.",
    "You are building not only muscle, but character.", "Repetition builds trust in yourself.", "The goal is big; the next step is small.", "Make your effort visible.", "Every honest set deserves respect.",
    "You decide how your story continues.", "Start with what is possible today.", "Strength grows when you use it.", "Be patient – progress works quietly.", "The will leads; the body learns.",
    "Train today. Be proud tomorrow.", "Do not go where the path leads. Go where there is no path and leave your trail.", "Not perfect – but consistent.", "Limits shift through daily work.", "THE.HUMAN.CHOICE: Your decision. Your progress."
  ]
};

const fr: MotivationContent = {
  goldenRulesTitle: "Les dix règles d’or",
  goldenRules: [
    ["Commence chaque journée par une réussite.", "Accomplis d’abord une tâche et démarre avec une sensation positive."], ["Ne parcours pas ton chemin seul.", "Entoure-toi de personnes qui te soutiennent et sois aussi présent pour elles."], ["Traite chaque personne avec respect.", "Le caractère se révèle dans la façon dont tu traites les autres."], ["La vie n’est pas toujours juste – avance malgré tout.", "Accepte les revers sans perdre ton objectif de vue."], ["N’aie pas peur d’échouer.", "Chaque erreur peut te rendre plus fort et meilleur."], ["Ose prendre des risques.", "La progression commence en dehors de ta zone de confort."], ["Défends-toi et défends les autres avec courage.", "Ne te laisse pas intimider et aide ceux qui en ont besoin."], ["Montre ta force quand tout devient difficile.", "C’est dans les moments difficiles que ton courage compte le plus."], ["Relève ceux qui sont à terre.", "La vraie force consiste à redonner de l’espoir aux autres."], ["N’abandonne jamais.", "Continue, même si le chemin est plus long et plus difficile que prévu."]
  ],
  quotes: [
    "Chaque répétition est une décision en ta faveur.", "La discipline commence là où les excuses s’arrêtent.", "Plus fort aujourd’hui qu’hier.", "Les petites séries construisent de grands objectifs.", "Tu n’as pas besoin d’une journée parfaite – seulement de la prochaine pompe.",
    "La régularité l’emporte sur la motivation.", "Ton corps suit ta décision.", "Une pompe, c’est peu. Mille décisions, c’est de la force.", "Commence avant de te sentir prêt.", "La force grandit avec les répétitions.",
    "Ton rythme est le bon tant que tu continues.", "Surveille tes pensées. Elles créent des actions.", "N’abandonne pas – adapte-toi et continue.", "Tu t’entraînes aujourd’hui pour la personne que tu seras demain.", "Le progrès demande de la patience et de l’honnêteté.",
    "Chaque pompe bien exécutée te rend meilleur.", "La volonté se renforce par l’action.", "Fais simple. Fais propre. Recommence.", "Ton seul rival, c’est la personne que tu étais hier.", "Une journée forte commence par une décision forte.",
    "Tu n’as pas besoin d’aller vite, seulement d’être régulier.", "Le succès se construit répétition après répétition.", "Reste calme, reste précis, continue.", "Même dix répétitions te font avancer.", "Ton objectif n’attend pas – va à sa rencontre.",
    "La discipline, c’est la motivation qui est restée.", "Aujourd’hui, ce sont les répétitions qui comptent, pas les excuses.", "Écris toi-même ta progression.", "La force se révèle dans la persévérance.", "Tu peux faire plus que ne te le dit ta première pensée.",
    "Entraîne-toi intelligemment et respecte ton corps.", "Les pauses sont permises. Abandonner est un choix.", "Une technique propre, c’est la vraie force.", "Chaque début a le droit d’être modeste.", "Ce qui est difficile aujourd’hui deviendra une routine demain.",
    "Tes habitudes construisent ton avenir.", "Un objectif devient réel lorsque tu agis chaque jour.", "Reste honnête envers toi-même et tes répétitions.", "Tu n’as pas besoin d’applaudissements, seulement de ta détermination.", "Le chemin vers cent commence par une répétition.",
    "La fatigue est une sensation, la discipline une décision.", "La force, c’est se relever et continuer.", "Ta progression n’a à plaire à personne – elle doit seulement t’appartenir.", "Une mauvaise journée ne signifie pas un mauvais objectif.", "Aujourd’hui est une nouvelle occasion de compter.",
    "Tu ne construis pas seulement des muscles, mais aussi ton caractère.", "La répétition renforce la confiance en toi.", "L’objectif est grand, la prochaine étape est petite.", "Rends tes efforts visibles.", "Chaque série honnête mérite le respect.",
    "C’est toi qui décides de la suite de ton histoire.", "Commence par ce qui est possible aujourd’hui.", "La force grandit quand tu l’utilises.", "Sois patient – le progrès travaille en silence.", "La volonté guide, le corps apprend.",
    "Entraîne-toi aujourd’hui. Sois fier demain.", "Ne va pas là où le chemin te mène. Va là où il n’y a pas de chemin et laisse ta trace.", "Pas parfait – mais régulier.", "Les limites reculent grâce au travail quotidien.", "THE.HUMAN.CHOICE : Ta décision. Ta progression."
  ]
};

const es: MotivationContent = {
  goldenRulesTitle: "Las diez reglas de oro",
  goldenRules: [
    ["Empieza cada día con un logro.", "Completa primero una tarea y empieza con una buena sensación."], ["No recorras tu camino en soledad.", "Busca personas que te apoyen y apóyalas tú también."], ["Trata a todos con respeto.", "El carácter se demuestra en cómo tratas a los demás."], ["La vida no siempre es justa – sigue adelante de todos modos.", "Acepta los contratiempos sin perder de vista tu meta."], ["No tengas miedo de fracasar.", "Cada error puede hacerte más fuerte y mejor."], ["Atrévete a correr riesgos.", "El crecimiento comienza fuera de tu zona de confort."], ["Defiéndete a ti y a los demás con valentía.", "No te dejes intimidar y ayuda a quien lo necesite."], ["Demuestra fortaleza cuando más difícil sea.", "En los momentos difíciles es cuando más cuenta tu valor."], ["Levanta a quienes están caídos.", "La verdadera fuerza consiste en dar esperanza a los demás."], ["Nunca te rindas.", "Sigue adelante, aunque el camino sea más largo y difícil de lo esperado."]
  ],
  quotes: [
    "Cada repetición es una decisión a tu favor.", "La disciplina comienza donde terminan las excusas.", "Hoy más fuerte que ayer.", "Las series pequeñas construyen grandes metas.", "No necesitas un día perfecto – solo la siguiente flexión.",
    "La constancia supera a la motivación.", "Tu cuerpo sigue tu decisión.", "Una flexión es poco. Mil decisiones son fortaleza.", "Empieza antes de sentirte preparado.", "La fuerza crece con la repetición.",
    "Tu ritmo es el adecuado mientras sigas adelante.", "Cuida tus pensamientos. Crean acciones.", "No te rindas – adáptate y continúa.", "Hoy entrenas para tu yo del futuro.", "El progreso requiere paciencia y honestidad.",
    "Cada flexión bien hecha te hace mejor.", "La fuerza de voluntad se fortalece actuando.", "Hazlo sencillo. Hazlo bien. Hazlo de nuevo.", "Tu única competencia eres tú mismo ayer.", "Un día fuerte empieza con una decisión firme.",
    "No tienes que ser rápido, solo constante.", "El éxito se construye repetición a repetición.", "Mantén la calma, hazlo bien y sigue.", "Incluso diez repeticiones te hacen avanzar.", "Tu objetivo no espera – ve a por él.",
    "La disciplina es la motivación que se quedó.", "Hoy cuentan las repeticiones, no las excusas.", "Escribe tú mismo tu progreso.", "La fuerza se demuestra perseverando.", "Puedes hacer más de lo que te dice tu primer pensamiento.",
    "Entrena con inteligencia y respeta tu cuerpo.", "Las pausas están permitidas. Rendirse es una decisión.", "Una técnica limpia es fuerza de verdad.", "Todo comienzo puede ser pequeño.", "Lo que hoy cuesta, mañana será rutina.",
    "Tus hábitos construyen tu futuro.", "Una meta se hace realidad cuando actúas cada día.", "Sé honesto contigo y con tus repeticiones.", "No necesitas aplausos, solo tu determinación.", "El camino hacia cien comienza con una repetición.",
    "El cansancio es una sensación; la disciplina, una decisión.", "La fuerza es levantarse y seguir adelante.", "Tu progreso no tiene que gustar a nadie – solo tiene que ser tuyo.", "Un mal día no convierte tu meta en mala.", "Hoy es una nueva oportunidad para contar.",
    "No solo construyes músculos, también carácter.", "La repetición genera confianza en ti mismo.", "La meta es grande; el siguiente paso, pequeño.", "Haz visible tu esfuerzo.", "Cada serie honesta merece respeto.",
    "Tú decides cómo continúa tu historia.", "Empieza con lo que hoy sea posible.", "La fuerza crece cuando la utilizas.", "Ten paciencia – el progreso trabaja en silencio.", "La voluntad guía; el cuerpo aprende.",
    "Entrena hoy. Siéntete orgulloso mañana.", "No vayas adonde conduce el camino. Ve adonde no hay camino y deja tu huella.", "No perfecto – pero constante.", "Los límites cambian con el trabajo diario.", "THE.HUMAN.CHOICE: Tu decisión. Tu progreso."
  ]
};

const it: MotivationContent = {
  goldenRulesTitle: "Le dieci regole d’oro",
  goldenRules: [
    ["Inizia ogni giornata con un successo.", "Completa prima un compito e parti con una sensazione positiva."], ["Non percorrere la tua strada da solo.", "Trova persone che ti sostengano e sii presente anche per loro."], ["Tratta tutti con rispetto.", "Il carattere si vede da come tratti gli altri."], ["La vita non è sempre giusta – vai comunque avanti.", "Accetta le battute d’arresto senza perdere di vista il tuo obiettivo."], ["Non avere paura di fallire.", "Ogni errore può renderti più forte e migliore."], ["Abbi il coraggio di rischiare.", "La crescita inizia fuori dalla tua zona di comfort."], ["Difendi con coraggio te stesso e gli altri.", "Non lasciarti intimidire e aiuta chi ha bisogno."], ["Mostra forza quando è più difficile.", "Nei momenti duri il tuo coraggio conta più che mai."], ["Rialza chi è a terra.", "La vera forza sta nel dare speranza agli altri."], ["Non arrenderti mai.", "Continua, anche quando il cammino è più lungo e difficile del previsto."]
  ],
  quotes: [
    "Ogni ripetizione è una scelta a favore di te stesso.", "La disciplina comincia dove finiscono le scuse.", "Oggi più forte di ieri.", "Le piccole serie costruiscono grandi obiettivi.", "Non ti serve una giornata perfetta – solo il prossimo push-up.",
    "La costanza batte la motivazione.", "Il tuo corpo segue la tua decisione.", "Un push-up è poco. Mille decisioni sono forza.", "Inizia prima di sentirti pronto.", "La forza cresce con la ripetizione.",
    "Il tuo ritmo è giusto finché continui.", "Fai attenzione ai tuoi pensieri. Creano azioni.", "Non arrenderti – adattati e continua.", "Oggi ti alleni per il te stesso del futuro.", "Il progresso richiede pazienza e onestà.",
    "Ogni push-up eseguito bene ti rende migliore.", "La forza di volontà cresce agendo.", "Fallo semplice. Fallo bene. Fallo di nuovo.", "Il tuo unico avversario sei tu ieri.", "Una giornata forte inizia con una decisione forte.",
    "Non devi essere veloce, solo costante.", "Il successo nasce una ripetizione alla volta.", "Resta calmo, resta preciso, continua.", "Anche dieci ripetizioni ti fanno avanzare.", "Il tuo obiettivo non aspetta – vai verso di lui.",
    "La disciplina è la motivazione che è rimasta.", "Oggi contano le ripetizioni, non le scuse.", "Scrivi tu stesso i tuoi progressi.", "La forza si vede nella perseveranza.", "Puoi fare più di quanto ti dica il primo pensiero.",
    "Allenati con intelligenza e rispetta il tuo corpo.", "Le pause sono consentite. Arrendersi è una scelta.", "Una tecnica pulita è vera forza.", "Ogni inizio può essere piccolo.", "Ciò che oggi è difficile domani sarà routine.",
    "Le tue abitudini costruiscono il tuo futuro.", "Un obiettivo diventa reale quando agisci ogni giorno.", "Sii onesto con te stesso e con le tue ripetizioni.", "Non ti servono applausi, solo la tua determinazione.", "La strada verso cento inizia con una ripetizione.",
    "La stanchezza è una sensazione; la disciplina è una decisione.", "La forza è rialzarsi e andare avanti.", "I tuoi progressi non devono piacere a nessuno – devono solo appartenerti.", "Una brutta giornata non è un brutto obiettivo.", "Oggi è una nuova occasione per contare.",
    "Non costruisci solo muscoli, ma anche carattere.", "La ripetizione crea fiducia in te stesso.", "L’obiettivo è grande; il prossimo passo è piccolo.", "Rendi visibile il tuo impegno.", "Ogni serie onesta merita rispetto.",
    "Sei tu a decidere come continua la tua storia.", "Inizia da ciò che oggi è possibile.", "La forza cresce quando la usi.", "Sii paziente – il progresso lavora in silenzio.", "La volontà guida; il corpo impara.",
    "Allenati oggi. Sii orgoglioso domani.", "Non andare dove porta il sentiero. Vai dove non c’è sentiero e lascia la tua traccia.", "Non perfetto – ma costante.", "I limiti si spostano con il lavoro quotidiano.", "THE.HUMAN.CHOICE: La tua decisione. I tuoi progressi."
  ]
};

const pt: MotivationContent = {
  goldenRulesTitle: "As dez regras de ouro",
  goldenRules: [
    ["Começa cada dia com uma conquista.", "Conclui primeiro uma tarefa e começa com uma sensação positiva."], ["Não percorra o seu caminho sozinho.", "Procure pessoas que o apoiem e esteja também presente para elas."], ["Trate todas as pessoas com respeito.", "O caráter revela-se na forma como trata os outros."], ["A vida nem sempre é justa – continue mesmo assim.", "Aceite os contratempos sem perder o seu objetivo de vista."], ["Não tenha medo de falhar.", "Cada erro pode torná-lo mais forte e melhor."], ["Atreva-se a correr riscos.", "O crescimento começa fora da sua zona de conforto."], ["Defenda-se a si e aos outros com coragem.", "Não se deixe intimidar e ajude quem precisa."], ["Mostre força quando for mais difícil.", "É nos momentos difíceis que a sua coragem mais conta."], ["Ajude a levantar quem está em baixo.", "A verdadeira força está em dar esperança aos outros."], ["Nunca desista.", "Continue, mesmo quando o caminho for mais longo e difícil do que esperava."]
  ],
  quotes: [
    "Cada repetição é uma decisão a seu favor.", "A disciplina começa onde as desculpas terminam.", "Hoje mais forte do que ontem.", "Pequenas séries constroem grandes objetivos.", "Não precisa de um dia perfeito – apenas da próxima flexão.",
    "A consistência supera a motivação.", "O seu corpo segue a sua decisão.", "Uma flexão é pouco. Mil decisões são força.", "Comece antes de se sentir preparado.", "A força cresce com a repetição.",
    "O seu ritmo é o certo enquanto continuar.", "Preste atenção aos seus pensamentos. Eles criam ações.", "Não desista – adapte-se e continue.", "Hoje treina para o seu eu do futuro.", "O progresso exige paciência e honestidade.",
    "Cada flexão bem executada torna-o melhor.", "A força de vontade fortalece-se através da ação.", "Faça simples. Faça bem. Faça de novo.", "O seu único adversário é quem era ontem.", "Um dia forte começa com uma decisão firme.",
    "Não precisa de ser rápido, apenas consistente.", "O sucesso constrói-se repetição após repetição.", "Mantenha a calma, faça bem e continue.", "Até dez repetições o fazem avançar.", "O seu objetivo não espera – vá ao encontro dele.",
    "A disciplina é a motivação que ficou.", "Hoje contam as repetições, não as desculpas.", "Escreva o seu próprio progresso.", "A força revela-se na persistência.", "Consegue mais do que o seu primeiro pensamento lhe diz.",
    "Treine com inteligência e respeite o seu corpo.", "As pausas são permitidas. Desistir é uma decisão.", "Uma técnica correta é força verdadeira.", "Todo o começo pode ser pequeno.", "O que hoje é difícil amanhã será rotina.",
    "Os seus hábitos constroem o seu futuro.", "Um objetivo torna-se real quando age todos os dias.", "Seja honesto consigo e com as suas repetições.", "Não precisa de aplausos, apenas da sua determinação.", "O caminho até cem começa com uma repetição.",
    "O cansaço é uma sensação; a disciplina é uma decisão.", "Força é levantar-se de novo e continuar.", "O seu progresso não tem de agradar a ninguém – só tem de ser seu.", "Um dia mau não é um objetivo mau.", "Hoje é uma nova oportunidade para contar.",
    "Não está apenas a construir músculos, mas também caráter.", "A repetição cria confiança em si próprio.", "O objetivo é grande; o próximo passo é pequeno.", "Torne o seu esforço visível.", "Cada série honesta merece respeito.",
    "É você que decide como a sua história continua.", "Comece com o que é possível hoje.", "A força cresce quando a utiliza.", "Tenha paciência – o progresso trabalha em silêncio.", "A vontade guia; o corpo aprende.",
    "Treine hoje. Sinta orgulho amanhã.", "Não vá por onde o caminho conduz. Vá por onde não há caminho e deixe a sua marca.", "Não perfeito – mas consistente.", "Os limites mudam com o trabalho diário.", "THE.HUMAN.CHOICE: A sua decisão. O seu progresso."
  ]
};

const hu: MotivationContent = {
  goldenRulesTitle:"A tíz aranyszabály",
  goldenRules:[
    ["Kezdj minden napot egy sikerrel.","Először végezz el egy feladatot, és jó érzéssel indulj."],
    ["Ne járd egyedül az utad.","Keress támogató embereket, és te is állj mellettük."],
    ["Mindenkivel bánj tisztelettel.","A jellemed abban mutatkozik meg, ahogyan másokkal bánsz."],
    ["Az élet nem mindig igazságos – haladj tovább.","Fogadd el a visszaeséseket anélkül, hogy szem elől tévesztenéd a célodat."],
    ["Ne félj a kudarctól.","Minden hiba erősebbé és jobbá tehet."],
    ["Merj kockázatot vállalni.","A fejlődés a komfortzónádon kívül kezdődik."],
    ["Állj ki bátran magadért és másokért.","Ne hagyd magad megfélemlíteni, és segíts annak, akinek szüksége van rá."],
    ["A legnehezebb pillanatban mutass erőt.","Nehéz időkben számít leginkább a bátorságod."],
    ["Emeld fel azt, aki elesett.","Az igazi erő reményt ad másoknak."],
    ["Soha ne add fel.","Folytasd akkor is, ha az út hosszabb és nehezebb a vártnál."]
  ],
  quotes:[
    "Minden ismétlés egy döntés önmagad mellett.","A fegyelem ott kezdődik, ahol a kifogás véget ér.","Ma erősebb vagy, mint tegnap.","Kis sorozatokból lesznek nagy célok.","Nem tökéletes nap kell, csak a következő fekvőtámasz.",
    "A következetesség legyőzi a motivációt.","A tested követi a döntésedet.","Egy fekvőtámasz kevésnek tűnik, ezer döntés már erő.","Kezdd el, mielőtt késznek érzed magad.","Az erő az ismétléssel növekszik.",
    "A tempód megfelelő, amíg haladsz.","Figyelj a gondolataidra, mert tetteket teremtenek.","Ne add fel: igazíts és folytasd.","Ma a jövőbeli önmagadért edzel.","A fejlődéshez türelem és becsületesség kell.",
    "Minden szabályos fekvőtámasz jobbá tesz.","Az akaraterő cselekvéssel erősödik.","Csináld egyszerűen, szabályosan, majd újra.","Egyetlen ellenfeled a tegnapi önmagad.","Egy erős nap erős döntéssel kezdődik.",
    "Nem kell gyorsnak lenned, csak következetesnek.","A siker ismétlésről ismétlésre épül.","Maradj nyugodt, pontos és kitartó.","Tíz ismétlés is előrevisz.","A célod nem vár: indulj felé.",
    "A fegyelem a megmaradt motiváció.","Ma az ismétlések számítanak, nem a kifogások.","Írd te a saját fejlődésed történetét.","Az erő a kitartásban mutatkozik meg.","Többre vagy képes, mint az első gondolatod mondja.",
    "Eddz okosan, és tiszteld a testedet.","Pihenni szabad; feladni döntés.","A szabályos technika valódi erő.","Minden kezdet lehet kicsi.","Ami ma nehéz, holnap rutin lesz.",
    "A szokásaid építik a jövődet.","A cél akkor válik valósággá, ha naponta teszel érte.","Légy őszinte magaddal és az ismétléseiddel.","Nem taps kell, hanem elhatározás.","A százhoz vezető út egy ismétléssel kezdődik.",
    "A fáradtság érzés, a fegyelem döntés.","Erő az, amikor újra felállsz és folytatod.","A fejlődésed a tiéd.","Egy rossz nap nem jelent rossz célt.","A mai nap új lehetőség.",
    "Nemcsak izmot, hanem jellemet is építesz.","Az ismétlés önbizalmat teremt.","A cél nagy, a következő lépés kicsi.","Tedd láthatóvá az erőfeszítésedet.","Minden becsületes sorozat tiszteletet érdemel.",
    "Te döntöd el, hogyan folytatódik a történeted.","Kezdd azzal, ami ma lehetséges.","Az erő használat közben növekszik.","Légy türelmes: a fejlődés csendben dolgozik.","Az akarat vezet, a test tanul.",
    "Ma eddz, holnap légy büszke.","Járatlan úton hagyd ott a nyomodat.","Nem tökéletes, de következetes.","A határok napi munkával mozdulnak el.","THE.HUMAN.CHOICE: A te döntésed. A te fejlődésed."
  ]
};

export const motivationContent: Record<Language, MotivationContent> = { de, en, fr, es, it, pt, hu, bg:en, tr:en, ar:en };
